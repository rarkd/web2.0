document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.getElementById('search-form');
    const searchInput = document.getElementById('search-input');
    const animeGrid = document.getElementById('anime-grid');
    const loadingElement = document.getElementById('loading');
    const noResultsElement = document.getElementById('no-results');
    
    searchForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const query = searchInput.value.trim();
        
        if (!query) return;
        
        try {
            // Show loading state
            loadingElement.classList.remove('hidden');
            noResultsElement.classList.add('hidden');
            animeGrid.innerHTML = '';
            
            // Fetch search results
            const data = await api.fetchData(`/anime?q=${encodeURIComponent(query)}&limit=24`);
            
            // Hide loading
            loadingElement.classList.add('hidden');
            
            // Check if results exist
            if (data.data && data.data.length > 0) {
                renderAnimeCards(data.data, animeGrid);
            } else {
                noResultsElement.classList.remove('hidden');
            }
        } catch (error) {
            loadingElement.classList.add('hidden');
            noResultsElement.classList.remove('hidden');
            noResultsElement.innerHTML = `
                <div class="text-6xl mb-4">⚠️</div>
                <h3 class="text-2xl font-bold mb-2">Search Failed</h3>
                <p class="text-gray-400">Something went wrong. Please try again.</p>
            `;
            console.error('Search error:', error);
        }
    });
    
    function renderAnimeCards(animeList, container) {
        container.innerHTML = '';
        
        animeList.forEach(anime => {
            const card = document.createElement('div');
            card.className = 'anime-card glass-morph rounded-2xl overflow-hidden cursor-pointer group';
            
            const imageUrl = anime.images?.jpg?.image_url || 'assets/placeholder.jpg';
            const score = anime.score || 'N/A';
            const episodes = anime.episodes || '?';
            const year = anime.year || '?';
            
            card.innerHTML = `
                <div class="relative h-80">
                    <img src="${imageUrl}" 
                         alt="${anime.title}" 
                         class="w-full h-full object-cover anime-poster"
                         onerror="this.src='assets/placeholder.jpg'">
                    
                    ${anime.score >= 8 ? '<div class="trending-badge">🔥 Popular</div>' : ''}
                    
                    <div class="absolute top-3 right-3">
                        <div class="px-3 py-1 bg-black/60 backdrop-blur-md text-white text-xs font-bold rounded-full border border-white/20">
                            ⭐ ${score}
                        </div>
                    </div>
                    
                    <div class="card-overlay">
                        <h3 class="text-white font-bold text-lg mb-3 line-clamp-2">${anime.title}</h3>
                        
                        <div class="space-y-2 mb-4">
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-300">Episodes:</span>
                                <span class="text-white font-semibold">${episodes}</span>
                            </div>
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-300">Year:</span>
                                <span class="text-white font-semibold">${year}</span>
                            </div>
                            <div class="flex items-center justify-between text-sm">
                                <span class="text-gray-300">Type:</span>
                                <span class="text-white font-semibold">${anime.type || 'TV'}</span>
                            </div>
                        </div>
                        
                        <button class="view-btn w-full py-3 bg-gradient-to-r from-lime-500 to-green-600 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-lime-500/50 transition-all transform hover:scale-105">
                            ▶ View Details
                        </button>
                    </div>
                </div>
            `;
            
            // Add event listeners
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.view-btn')) {
                    window.location.href = `detail.html?id=${anime.mal_id}`;
                }
            });
            
            const viewButton = card.querySelector('.view-btn');
            viewButton.addEventListener('click', (e) => {
                e.stopPropagation();
                window.location.href = `detail.html?id=${anime.mal_id}`;
            });
            
            container.appendChild(card);
        });
    }
});