document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const animeId = urlParams.get('id');
    const animeTitle = urlParams.get('title') || 'Unknown Anime';
    
    const loadingElement = document.getElementById('loading');
    const playerContainer = document.getElementById('player-container');
    const noStreamElement = document.getElementById('no-stream');
    const titleElement = document.getElementById('anime-title');
    const episodeSelect = document.getElementById('episode-select');
    const streamSelect = document.getElementById('stream-select');
    const videoFrame = document.getElementById('video-frame');
    const qualityOptions = document.getElementById('quality-options');
    
    if (!animeId) {
        loadingElement.textContent = 'Invalid anime ID';
        return;
    }
    
    // Set title
    titleElement.textContent = animeTitle;
    
    try {
        // Fetch anime details to get episode count
        const data = await api.fetchData(`/anime/${animeId}`);
        const anime = data.data;
        const episodeCount = anime.episodes || 12; // Default jika tidak ada info
        
        // Load video mapping data
        const videoMapping = await loadVideoMapping();
        
        // Check if streaming data exists for this anime
        const hasStreamData = checkStreamAvailability(animeId, videoMapping);
        
        if (!hasStreamData) {
            loadingElement.classList.add('hidden');
            noStreamElement.classList.remove('hidden');
            return;
        }
        
        // Hide loading and show player
        loadingElement.classList.add('hidden');
        playerContainer.classList.remove('hidden');
        
        // Create episode options
        for (let i = 1; i <= episodeCount; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `Episode ${i}`;
            episodeSelect.appendChild(option);
        }
        
        // Set default video (first episode, first stream)
        loadStreamVideo(animeId, 1, streamSelect.value, videoMapping);
        
        // Change video when episode changes
        episodeSelect.addEventListener('change', (e) => {
            const episode = parseInt(e.target.value);
            loadStreamVideo(animeId, episode, streamSelect.value, videoMapping);
        });
        
        // Change video when stream source changes
        streamSelect.addEventListener('change', (e) => {
            const episode = parseInt(episodeSelect.value);
            loadStreamVideo(animeId, episode, e.target.value, videoMapping);
        });
        
        // Setup quality options
        setupQualityOptions();
        
    } catch (error) {
        loadingElement.textContent = 'Failed to load anime details. Please try again later.';
        console.error('Error fetching anime details:', error);
    }
});

async function loadVideoMapping() {
    try {
        const response = await fetch('js/video-mapping.json');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        return data.anime_videos;
    } catch (error) {
        console.error('Error loading video mapping:', error);
        return {};
    }
}

function checkStreamAvailability(animeId, videoMapping) {
    return videoMapping && videoMapping[animeId] !== undefined;
}

function loadStreamVideo(animeId, episode, streamSource, videoMapping) {
    // Mapping stream source ke domain masing-masing
    const streamDomains = {
        // 'hydrax': 'https://hydrax.net/embed',
        'hydrax': 'https://short.icu/',
        'vidhide': 'https://vidhide.com/e',
        'turbovidplay': 'https://turbovidplay.com/embed',
        'streamhg': 'https://streamhg.com/embed'
    };
    
    // Get video ID from mapping
    const animeData = videoMapping[animeId];
    if (!animeData) {
        console.error(`No video data found for anime ID: ${animeId}`);
        return;
    }
    
    const episodeData = animeData.episodes[episode];
    if (!episodeData) {
        console.error(`No video data found for episode ${episode} of anime ID: ${animeId}`);
        return;
    }
    
    const videoId = episodeData[streamSource];
    if (!videoId) {
        console.error(`No video ID found for ${streamSource} stream of episode ${episode}`);
        return;
    }
    
    // Construct embed URL
    let embedUrl = '';
    switch(streamSource) {
        case 'hydrax':
            embedUrl = `${streamDomains.hydrax}/${videoId}`;
            break;
        case 'vidhide':
            embedUrl = `${streamDomains.vidhide}/${videoId}`;
            break;
        case 'turbovidplay':
            embedUrl = `${streamDomains.turbovidplay}/${videoId}`;
            break;
        case 'streamhg':
            embedUrl = `${streamDomains.streamhg}/${videoId}`;
            break;
        default:
            embedUrl = `${streamDomains.hydrax}/${videoId}`;
    }
    
    // Set iframe source
    const videoFrame = document.getElementById('video-frame');
    videoFrame.src = embedUrl;
}

function setupQualityOptions() {
    const qualityOptions = document.getElementById('quality-options');
    qualityOptions.innerHTML = '';
    
    const qualities = ['1080p', '720p', '480p', '360p'];
    
    qualities.forEach((quality, index) => {
        const button = document.createElement('button');
        button.className = `quality-btn ${index === 1 ? 'active' : ''}`;
        button.textContent = quality;
        button.dataset.quality = quality;
        
        button.addEventListener('click', () => {
            document.querySelectorAll('.quality-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            button.classList.add('active');
            console.log(`Quality changed to: ${quality}`);
        });
        
        qualityOptions.appendChild(button);
    });
}

// Add CSS styles
const style = document.createElement('style');
style.textContent = `
    .quality-selector {
        margin-top: 15px;
    }
    
    .quality-selector label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
    }
    
    #quality-options {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }
    
    .quality-btn {
        background-color: #2d2d2d;
        color: #f0f0f0;
        border: 1px solid #444;
        padding: 8px 15px;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.3s;
    }
    
    .quality-btn:hover {
        background-color: #3d3d3d;
    }
    
    .quality-btn.active {
        background-color: #e91e63;
        border-color: #e91e63;
    }
    
    .stream-selector {
        margin: 15px 0;
    }
    
    .stream-selector label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
    }
    
    .stream-selector select {
        width: 200px;
        padding: 10px;
        border-radius: 4px;
        background-color: #2d2d2d;
        color: #f0f0f0;
        border: 1px solid #444;
    }
    
    .no-results {
        text-align: center;
        padding: 40px;
        background-color: #1e1e1e;
        border-radius: 8px;
        margin-top: 20px;
    }
    
    .no-results p {
        margin: 10px 0;
        color: #bbb;
    }
`;
document.head.appendChild(style);