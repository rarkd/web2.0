// Genre icons mapping
const genreIcons = {
    'Action': '⚔️',
    'Adventure': '🗺️',
    'Comedy': '😂',
    'Drama': '🎭',
    'Fantasy': '🔮',
    'Horror': '👻',
    'Mystery': '🔍',
    'Romance': '💖',
    'Sci-Fi': '🚀',
    'Slice of Life': '🌸',
    'Sports': '⚽',
    'Supernatural': '✨',
    'Thriller': '😱',
    'Psychological': '🧠',
    'Mecha': '🤖',
    'Music': '🎵',
    'School': '🎒',
    'Military': '🎖️',
    'Historical': '📜',
    'Seinen': '👔',
    'Shounen': '💪',
    'Shoujo': '🌹',
    'Josei': '👗',
    'Kids': '👶',
    'Dementia': '🌀',
    'Demons': '😈',
    'Ecchi': '🔥',
    'Game': '🎮',
    'Harem': '💐',
    'Magic': '✨',
    'Martial Arts': '🥋',
    'Parody': '🎪',
    'Police': '🚓',
    'Samurai': '⚔️',
    'Space': '🌌',
    'Super Power': '⚡',
    'Vampire': '🧛',
    'Hentai': '🔞',
    'Cars': '🏎️',
    'Dementia': '🌀'
};

// Get icon for genre
function getGenreIcon(genreName) {
    return genreIcons[genreName] || '📺';
}

// State management
let currentGenreId = null;
let currentGenreName = '';
let currentPage = 1;
let limit = 24; // Increased for better pagination
let totalPages = 1;
let allAnimeData = [];
let currentFilters = {
    type: '',
    status: '',
    sort: 'popularity'
};

document.addEventListener('DOMContentLoaded', async () => {
    const genresGrid = document.getElementById('genresGrid');
    const animeGrid = document.getElementById('animeGrid');
    const genreTitle = document.getElementById('genreTitle');
    const genreLoading = document.getElementById('genreLoading');
    const animeLoading = document.getElementById('animeLoading');
    const genreListView = document.getElementById('genreListView');
    const animeByGenreView = document.getElementById('animeByGenreView');
    const paginationControls = document.getElementById('paginationControls');
    const genreSearch = document.getElementById('genreSearch');
    const backToGenresBtn = document.getElementById('backToGenres');
    const sortSelect = document.getElementById('sortSelect');
    const typeFilter = document.getElementById('typeFilter');
    const statusFilter = document.getElementById('statusFilter');
    
    let allGenres = [];
    
    try {
        // Fetch genres
        const genreData = await api.fetchData('/genres/anime');
        allGenres = genreData.data;
        
        // Hide loading
        genreLoading.classList.add('hidden');
        genresGrid.classList.remove('hidden');
        
        // Render genre cards
        renderGenreCards(allGenres, genresGrid);
        
        // Genre search functionality
        genreSearch.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const filteredGenres = allGenres.filter(genre => 
                genre.name.toLowerCase().includes(searchTerm)
            );
            renderGenreCards(filteredGenres, genresGrid);
        });
        
        // Back to genres button
        backToGenresBtn.addEventListener('click', () => {
            animeByGenreView.classList.add('hidden');
            genreListView.classList.remove('hidden');
            currentGenreId = null;
            currentPage = 1;
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        
        // Filter change handlers
        sortSelect.addEventListener('change', (e) => {
            currentFilters.sort = e.target.value;
            applyFiltersAndSort();
        });
        
        typeFilter.addEventListener('change', (e) => {
            currentFilters.type = e.target.value;
            applyFiltersAndSort();
        });
        
        statusFilter.addEventListener('change', (e) => {
            currentFilters.status = e.target.value;
            applyFiltersAndSort();
        });
        
        // Pagination handlers
        document.getElementById('prevPage').addEventListener('click', () => {
            if (currentPage > 1) {
                goToPage(currentPage - 1);
            }
        });
        
        document.getElementById('nextPage').addEventListener('click', () => {
            if (currentPage < totalPages) {
                goToPage(currentPage + 1);
            }
        });
        
    } catch (error) {
        genreLoading.innerHTML = '<p class="text-red-400 font-semibold">Failed to load genres. Please try again later.</p>';
        console.error('Error fetching genres:', error);
    }
    
    function renderGenreCards(genres, container) {
        container.innerHTML = '';
        
        genres.forEach((genre, index) => {
            const card = document.createElement('div');
            card.className = 'genre-card stagger-item';
            card.style.animationDelay = `${index * 0.05}s`;
            card.style.transform = 'translateY(20px)';
            
            const icon = getGenreIcon(genre.name);
            
            card.innerHTML = `
                <span class="genre-icon">${icon}</span>
                <h3 class="genre-name">${genre.name}</h3>
                <p class="genre-count">Explore titles</p>
            `;
            
            card.addEventListener('click', async () => {
                await loadGenreAnime(genre.mal_id, genre.name);
            });
            
            container.appendChild(card);
        });
    }
    
    async function loadGenreAnime(genreId, genreName) {
        currentGenreId = genreId;
        currentGenreName = genreName;
        currentPage = 1;
        
        // Update UI
        genreListView.classList.add('hidden');
        animeByGenreView.classList.remove('hidden');
        animeLoading.classList.remove('hidden');
        animeGrid.innerHTML = '';
        
        // Update title
        genreTitle.querySelector('span').textContent = genreName;
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        try {
            // Fetch total count
            const totalCountResponse = await api.fetchData(`/anime?genres=${genreId}&limit=1`);
            const totalCount = totalCountResponse.pagination.items.total;
            totalPages = Math.ceil(totalCount / limit);
            
            // Update stats
            document.getElementById('totalAnime').textContent = `${totalCount.toLocaleString()} Anime`;
            
            // Fetch anime data
            const animeData = await api.fetchData(`/anime?genres=${genreId}&limit=${limit}&page=${currentPage}&order_by=popularity`);
            allAnimeData = animeData.data;
            
            // Hide loading
            animeLoading.classList.add('hidden');
            
            // Apply filters and render
            applyFiltersAndSort();
            
        } catch (error) {
            animeLoading.classList.add('hidden');
            animeGrid.innerHTML = '<p class="col-span-full text-center text-red-400 font-semibold py-12">Failed to load anime. Please try again.</p>';
            console.error('Error fetching anime by genre:', error);
        }
    }
    
    function applyFiltersAndSort() {
        let filteredData = [...allAnimeData];
        
        // Apply type filter
        if (currentFilters.type) {
            filteredData = filteredData.filter(anime => 
                anime.type && anime.type.toLowerCase() === currentFilters.type.toLowerCase()
            );
        }
        
        // Apply status filter
        if (currentFilters.status) {
            filteredData = filteredData.filter(anime => 
                anime.status && anime.status.toLowerCase().includes(currentFilters.status.toLowerCase())
            );
        }
        
        // Apply sorting
        switch(currentFilters.sort) {
            case 'score':
                filteredData.sort((a, b) => (b.score || 0) - (a.score || 0));
                break;
            case 'title':
                filteredData.sort((a, b) => a.title.localeCompare(b.title));
                break;
            case 'episodes':
                filteredData.sort((a, b) => (b.episodes || 0) - (a.episodes || 0));
                break;
            case 'popularity':
            default:
                filteredData.sort((a, b) => (a.popularity || 999999) - (b.popularity || 999999));
                break;
        }
        
        renderAnimeCards(filteredData, animeGrid);
        renderPaginationControls();
    }
    
    async function goToPage(page) {
        if (!currentGenreId || page < 1 || page > totalPages) return;
        
        animeLoading.classList.remove('hidden');
        animeGrid.innerHTML = '';
        
        // Scroll to top of anime grid
        animeByGenreView.scrollIntoView({ behavior: 'smooth' });
        
        try {
            currentPage = page;
            
            // Build query params
            let orderBy = 'popularity';
            switch(currentFilters.sort) {
                case 'score': orderBy = 'score'; break;
                case 'title': orderBy = 'title'; break;
                case 'episodes': orderBy = 'episodes'; break;
            }
            
            let queryParams = `genres=${currentGenreId}&limit=${limit}&page=${currentPage}&order_by=${orderBy}`;
            
            if (currentFilters.type) {
                queryParams += `&type=${currentFilters.type}`;
            }
            if (currentFilters.status) {
                queryParams += `&status=${currentFilters.status}`;
            }
            
            const animeData = await api.fetchData(`/anime?${queryParams}`);
            allAnimeData = animeData.data;
            
            animeLoading.classList.add('hidden');
            
            applyFiltersAndSort();
            
        } catch (error) {
            animeLoading.classList.add('hidden');
            animeGrid.innerHTML = '<p class="col-span-full text-center text-red-400 font-semibold py-12">Failed to load anime. Please try again.</p>';
            console.error('Error fetching anime by page:', error);
        }
    }
    
    function renderPaginationControls() {
        // Update buttons
        document.getElementById('prevPage').disabled = currentPage === 1;
        document.getElementById('nextPage').disabled = currentPage === totalPages;
        
        // Render page numbers
        renderPageNumbers();
        
        // Show/hide pagination
        if (totalPages > 1) {
            paginationControls.classList.remove('hidden');
        } else {
            paginationControls.classList.add('hidden');
        }
    }
    
    function renderPageNumbers() {
        const pageNumbersContainer = document.getElementById('pageNumbers');
        pageNumbersContainer.innerHTML = '';
        
        // Calculate range
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, currentPage + 2);
        
        // Adjust for edges
        if (endPage - startPage < 4) {
            if (startPage === 1) {
                endPage = Math.min(totalPages, startPage + 4);
            } else if (endPage === totalPages) {
                startPage = Math.max(1, endPage - 4);
            }
        }
        
        // Add first page if not in range
        if (startPage > 1) {
            addPageNumber(1, pageNumbersContainer);
            if (startPage > 2) {
                const ellipsis = document.createElement('span');
                ellipsis.className = 'text-gray-400 px-2';
                ellipsis.textContent = '...';
                pageNumbersContainer.appendChild(ellipsis);
            }
        }
        
        // Add page numbers
        for (let i = startPage; i <= endPage; i++) {
            addPageNumber(i, pageNumbersContainer);
        }
        
        // Add last page if not in range
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                const ellipsis = document.createElement('span');
                ellipsis.className = 'text-gray-400 px-2';
                ellipsis.textContent = '...';
                pageNumbersContainer.appendChild(ellipsis);
            }
            addPageNumber(totalPages, pageNumbersContainer);
        }
    }
    
    function addPageNumber(pageNum, container) {
        const pageNumber = document.createElement('div');
        pageNumber.className = `page-number ${pageNum === currentPage ? 'active' : ''}`;
        pageNumber.textContent = pageNum;
        pageNumber.addEventListener('click', () => goToPage(pageNum));
        container.appendChild(pageNumber);
    }
    
    function renderAnimeCards(animeList, container) {
        container.innerHTML = '';
        
        if (animeList.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-20">
                    <div class="text-6xl mb-4">😔</div>
                    <p class="text-xl text-gray-400 font-semibold">No anime found with current filters</p>
                    <button onclick="location.reload()" class="mt-6 glow-btn relative z-10">
                        <span class="relative z-10">Reset Filters</span>
                    </button>
                </div>
            `;
            return;
        }
        
        animeList.forEach((anime, index) => {
            const card = document.createElement('div');
            card.className = 'anime-card stagger-item cursor-pointer';
            card.style.animationDelay = `${index * 0.05}s`;
            card.style.transform = 'translateY(20px)';
            
            const imageUrl = anime.images?.jpg?.image_url || 'assets/placeholder.jpg';
            const score = anime.score ? anime.score.toFixed(1) : 'N/A';
            const episodes = anime.episodes || '?';
            const year = anime.year || '?';
            const status = anime.status || 'Unknown';
            
            card.innerHTML = `
                <div class="relative">
                    <div class="h-72 overflow-hidden">
                        <img src="${imageUrl}" 
                             alt="${anime.title}" 
                             class="w-full h-full object-cover"
                             onerror="this.src='assets/placeholder.jpg'">
                    </div>
                    <div class="absolute top-3 right-3">
                        <span class="score-badge">
                            ⭐ ${score}
                        </span>
                    </div>
                    ${anime.type ? `
                        <div class="absolute top-3 left-3">
                            <span class="px-3 py-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs font-bold rounded-full">
                                ${anime.type}
                            </span>
                        </div>
                    ` : ''}
                </div>
                
                <div class="p-5">
                    <h3 class="text-lg font-bold text-white mb-3 line-clamp-2 min-h-[3.5rem]">${anime.title}</h3>
                    
                    <div class="space-y-2 mb-4">
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-400">Episodes:</span>
                            <span class="font-medium text-lime-400">${episodes}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-400">Year:</span>
                            <span class="font-medium text-lime-400">${year}</span>
                        </div>
                        <div class="flex justify-between text-sm">
                            <span class="text-gray-400">Status:</span>
                            <span class="font-medium text-lime-400 text-xs">${status}</span>
                        </div>
                    </div>
                    
                    <button class="w-full py-2.5 bg-gradient-to-r from-lime-500 to-green-600 hover:from-lime-600 hover:to-green-700 text-white font-bold rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg">
                        Watch Now
                    </button>
                </div>
            `;
            
            // Click handler
            card.addEventListener('click', (e) => {
                if (!e.target.closest('button')) {
                    window.location.href = `detail.html?id=${anime.mal_id}`;
                }
            });
            
            // Button click handler
            const watchButton = card.querySelector('button');
            watchButton.addEventListener('click', (e) => {
                e.stopPropagation();
                window.location.href = `detail.html?id=${anime.mal_id}`;
            });
            
            container.appendChild(card);
        });
    }
});