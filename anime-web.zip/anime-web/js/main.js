// State untuk melacak data
let allAnime = [];
let seasonalAnime = [];
let currentOffset = 0;
const limit = 20;

document.addEventListener('DOMContentLoaded', async () => {
    const animeGrid = document.getElementById('anime-grid');
    const loadingElement = document.getElementById('loading');
    const seasonContainer = document.getElementById('season-container');
    const seasonLoading = document.getElementById('season-loading');
    
    try {
        // Fetch top anime
        loadingElement.classList.remove('hidden');
        const data = await api.fetchData('/top/anime?limit=20');
        
        // Clear loading indicator
        loadingElement.classList.add('hidden');
        
        // Render anime cards
        renderAnimeCards(data.data, animeGrid);
        
        // Fetch seasonal anime
        seasonLoading.classList.remove('hidden');
        const seasonData = await fetchSeasonalAnime();
        seasonalAnime = seasonData;
        
        // Hide season loading
        seasonLoading.classList.add('hidden');
        seasonContainer.classList.remove('hidden');
        
        // Render seasonal anime
        renderSeasonAnime(seasonalAnime, seasonContainer);
        
        // Fetch top rating anime
        const topRatingData = await api.fetchData('/top/anime?limit=10&filter=bypopularity');
        renderTopRatingList(topRatingData.data, document.getElementById('top-rating-list'));
        
    } catch (error) {
        loadingElement.innerHTML = `
            <div class="text-center">
                <div class="text-red-400 text-xl mb-2">⚠️</div>
                <p class="text-gray-400">Failed to load anime. Please try again later.</p>
            </div>
        `;
        console.error('Error fetching top anime:', error);
    }
});

// Fungsi untuk fetch seasonal anime
async function fetchSeasonalAnime() {
    const currentYear = new Date().getFullYear();
    const currentSeason = getCurrentSeason();
    try {
        const data = await api.fetchData(`/seasons/${currentYear}/${currentSeason}?limit=15`);
        return data.data || [];
    } catch (error) {
        console.error('Error fetching seasonal anime:', error);
        return [];
    }
}

// Fungsi untuk mendapatkan season saat ini
function getCurrentSeason() {
    const month = new Date().getMonth() + 1;
    if (month >= 1 && month <= 3) return 'winter';
    if (month >= 4 && month <= 6) return 'spring';
    if (month >= 7 && month <= 9) return 'summer';
    return 'fall';
}

// Fungsi untuk render seasonal anime dengan design modern
function renderSeasonAnime(animeList, container) {
    container.innerHTML = '';
    
    if (animeList.length === 0) {
        container.innerHTML = '<p class="text-gray-400 text-center py-8">No seasonal anime found.</p>';
        return;
    }
    
    animeList.forEach(anime => {
        const card = document.createElement('div');
        card.className = 'anime-card glass-morph min-w-[200px] max-w-[200px] rounded-2xl overflow-hidden cursor-pointer';
        
        const imageUrl = anime.images?.jpg?.image_url || 'assets/placeholder.jpg';
        const score = anime.score || 'N/A';
        
        card.innerHTML = `
            <div class="relative h-72">
                <img src="${imageUrl}" 
                     alt="${anime.title}" 
                     class="w-full h-full object-cover anime-poster"
                     onerror="this.src='assets/placeholder.jpg'">
                
                ${anime.score >= 8 ? '<div class="trending-badge">🔥 HOT</div>' : ''}
                
                <div class="card-overlay">
                    <h3 class="text-white font-bold text-sm mb-2 line-clamp-2">${anime.title}</h3>
                    <div class="flex items-center gap-2">
                        <span class="px-3 py-1 bg-lime-500/90 backdrop-blur-sm text-white text-xs font-bold rounded-full">
                            ⭐ ${score}
                        </span>
                    </div>
                </div>
            </div>
        `;
        
        card.addEventListener('click', () => {
            window.location.href = `detail.html?id=${anime.mal_id}`;
        });
        
        container.appendChild(card);
    });
}

// Fungsi untuk render anime cards dengan design modern
function renderAnimeCards(animeList, container) {
    container.innerHTML = '';
    
    animeList.forEach(anime => {
        const card = document.createElement('div');
        card.className = 'anime-card glass-morph rounded-2xl overflow-hidden cursor-pointer group';
        
        const imageUrl = anime.images?.jpg?.image_url || 'assets/placeholder.jpg';
        const score = anime.score || 'N/A';
        const episodes = anime.episodes || '?';
        const year = anime.year || '?';
        
        card.innerHTML = `
            <div class="relative h-80">
                <img src="${imageUrl}" 
                     alt="${anime.title}" 
                     class="w-full h-full object-cover anime-poster"
                     onerror="this.src='assets/placeholder.jpg'">
                
                ${anime.score >= 8 ? '<div class="trending-badge">🔥 Trending</div>' : ''}
                
                <div class="absolute top-3 right-3">
                    <div class="px-3 py-1 bg-black/60 backdrop-blur-md text-white text-xs font-bold rounded-full border border-white/20">
                        ⭐ ${score}
                    </div>
                </div>
                
                <div class="card-overlay">
                    <h3 class="text-white font-bold text-lg mb-3 line-clamp-2">${anime.title}</h3>
                    
                    <div class="space-y-2 mb-4">
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-300">Episodes:</span>
                            <span class="text-white font-semibold">${episodes}</span>
                        </div>
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-300">Year:</span>
                            <span class="text-white font-semibold">${year}</span>
                        </div>
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-300">Type:</span>
                            <span class="text-white font-semibold">${anime.type || 'TV'}</span>
                        </div>
                    </div>
                    
                    <button class="watch-btn w-full py-3 bg-gradient-to-r from-lime-500 to-green-600 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-lime-500/50 transition-all transform hover:scale-105">
                        ▶ Watch Now
                    </button>
                </div>
            </div>
        `;
        
        card.addEventListener('click', (e) => {
            if (!e.target.closest('.watch-btn')) {
                window.location.href = `detail.html?id=${anime.mal_id}`;
            }
        });
        
        const watchButton = card.querySelector('.watch-btn');
        watchButton.addEventListener('click', (e) => {
            e.stopPropagation();
            window.location.href = `detail.html?id=${anime.mal_id}`;
        });
        
        container.appendChild(card);
    });
}

// Fungsi untuk render top rating list dengan design modern
function renderTopRatingList(animeList, container) {
    container.innerHTML = '';
    
    animeList.forEach((anime, index) => {
        const rank = index + 1;
        
        const item = document.createElement('a');
        item.href = `detail.html?id=${anime.mal_id}`;
        item.className = 'block p-4 rounded-xl hover:bg-white/5 transition-all duration-300 group cursor-pointer border border-transparent hover:border-lime-500/30';
        
        item.innerHTML = `
            <div class="flex items-center gap-4">
                <div class="rank-badge ${rank <= 3 ? 'rank-' + rank : 'bg-gradient-to-br from-gray-700 to-gray-600'} flex-shrink-0">
                    #${rank}
                </div>
                
                <div class="relative flex-shrink-0 w-16 h-20 rounded-lg overflow-hidden">
                    <img src="${anime.images?.jpg?.image_url || 'assets/placeholder.jpg'}" 
                         alt="${anime.title}" 
                         class="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-300"
                         onerror="this.src='assets/placeholder.jpg'">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                </div>
                
                <div class="flex-1 min-w-0">
                    <h3 class="text-white font-bold text-lg mb-1 truncate group-hover:text-lime-400 transition-colors">${anime.title}</h3>
                    <p class="text-gray-400 text-sm">
                        <span class="inline-flex items-center gap-1">
                            <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                                <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
                            </svg>
                            ${anime.type || 'TV'}
                        </span>
                        <span class="mx-2">•</span>
                        <span>${anime.episodes || '?'} eps</span>
                    </p>
                </div>
                
                <div class="flex-shrink-0 text-right">
                    <div class="flex items-center gap-1 mb-1">
                        <span class="text-2xl">⭐</span>
                        <span class="text-white font-black text-xl">${anime.score || 'N/A'}</span>
                    </div>
                    <div class="text-xs text-gray-400">
                        ${anime.members ? `${(anime.members / 1000000).toFixed(1)}M fans` : ''}
                    </div>
                </div>
            </div>
        `;
        
        container.appendChild(item);
    });
}