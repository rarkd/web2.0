// Base API configuration
const BASE_API_URL = 'https://api.jikan.moe/v4';

// Helper function to fetch data from API
async function fetchData(endpoint) {
    try {
        const response = await fetch(`${BASE_API_URL}${endpoint}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Fetch error:', error);
        throw error;
    }
}

// Export functions for use in other modules
window.api = {
    fetchData
};