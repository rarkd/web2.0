document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const animeId = urlParams.get('id');
    const animeTitle = urlParams.get('title') || 'Unknown Anime';
    
    const loadingElement = document.getElementById('loading');
    const playerContainer = document.getElementById('player-container');
    const titleElement = document.getElementById('anime-title');
    const episodeSelect = document.getElementById('episode-select');
    const videoFrame = document.getElementById('video-frame');
    
    if (!animeId) {
        loadingElement.textContent = 'Invalid anime ID';
        return;
    }
    
    // Set title
    titleElement.textContent = animeTitle;
    
    // Hide loading and show player
    loadingElement.classList.add('hidden');
    playerContainer.classList.remove('hidden');
    
    // Create episode options (using YouTube placeholder videos)
    // In a real app, these would come from your own streaming service
    const episodeCount = 24; // Default value
    
    for (let i = 1; i <= episodeCount; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = `Episode ${i}`;
        episodeSelect.appendChild(option);
    }
    
    // Set default video (YouTube placeholder)
    videoFrame.src = 'https://www.youtube.com/embed/dQw4w9WgXcQ'; // Rickroll as placeholder
    
    // Change video when episode changes
    episodeSelect.addEventListener('change', (e) => {
        const episode = e.target.value;
        // In a real implementation, you would get the actual video URL here
        // For demo purposes, we'll just change the YouTube video ID slightly
        const videoIds = [
            'dQw4w9WgXcQ', // Rickroll
            'DLzxrzFCyOs', // Another placeholder
            'jNQXAC9IVRw', // Yet another
            '9bZkp7q19f0'  // Gangnam Style
        ];
        
        // Cycle through different videos for variety
        const videoIndex = (episode - 1) % videoIds.length;
        videoFrame.src = `https://www.youtube.com/embed/${videoIds[videoIndex]}`;
    });
});