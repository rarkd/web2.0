// State management
let allAnimeData = [];
let filteredAnimeData = [];
let currentPage = 1;
let itemsPerPage = 24;
let totalPages = 1;
let isLoading = false;

// Filter state
let currentFilters = {
    search: '',
    type: '',
    status: '',
    sort: 'title-asc'
};

// View mode state
let viewMode = 'grid'; // 'grid' or 'compact'

document.addEventListener('DOMContentLoaded', async () => {
    const loading = document.getElementById('loading');
    const animeGrid = document.getElementById('animeGrid');
    const paginationControls = document.getElementById('paginationControls');
    const searchInput = document.getElementById('searchInput');
    const sortSelect = document.getElementById('sortSelect');
    const typeFilter = document.getElementById('typeFilter');
    const statusFilter = document.getElementById('statusFilter');
    const gridViewBtn = document.getElementById('gridView');
    const compactViewBtn = document.getElementById('compactView');
    
    try {
        // Show loading
        loading.classList.remove('hidden');
        
        // Fetch all anime data (multiple pages)
        await fetchAllAnime();
        
        // Initial sort
        applyFiltersAndSort();
        
        // Hide loading
        loading.classList.add('hidden');
        
        // Update total count
        document.getElementById('totalCount').textContent = `${allAnimeData.length.toLocaleString()} Anime`;
        
        // Render first page
        renderCurrentPage();
        
    } catch (error) {
        console.error('Error loading anime:', error);
        loading.innerHTML = '<p class="text-red-400 font-semibold">Failed to load anime. Please try again later.</p>';
    }
    
    // Search functionality with debounce
    let searchTimeout;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            currentFilters.search = e.target.value.toLowerCase();
            currentPage = 1;
            applyFiltersAndSort();
            renderCurrentPage();
        }, 300);
    });
    
    // Sort change
    sortSelect.addEventListener('change', (e) => {
        currentFilters.sort = e.target.value;
        applyFiltersAndSort();
        renderCurrentPage();
    });
    
    // Type filter change
    typeFilter.addEventListener('change', (e) => {
        currentFilters.type = e.target.value;
        currentPage = 1;
        applyFiltersAndSort();
        renderCurrentPage();
    });
    
    // Status filter change
    statusFilter.addEventListener('change', (e) => {
        currentFilters.status = e.target.value;
        currentPage = 1;
        applyFiltersAndSort();
        renderCurrentPage();
    });
    
    // View mode toggle
    gridViewBtn.addEventListener('click', () => {
        viewMode = 'grid';
        gridViewBtn.classList.add('active');
        compactViewBtn.classList.remove('active');
        animeGrid.classList.remove('grid-compact');
        animeGrid.classList.add('grid-comfortable');
        animeGrid.className = animeGrid.className.replace(/xl:grid-cols-\d+/, 'xl:grid-cols-6');
    });
    
    compactViewBtn.addEventListener('click', () => {
        viewMode = 'compact';
        compactViewBtn.classList.add('active');
        gridViewBtn.classList.remove('active');
        animeGrid.classList.remove('grid-comfortable');
        animeGrid.classList.add('grid-compact');
        animeGrid.className = animeGrid.className.replace(/xl:grid-cols-\d+/, 'xl:grid-cols-8');
        itemsPerPage = 32;
        renderCurrentPage();
    });
    
    // Pagination controls
    document.getElementById('prevPage').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderCurrentPage();
            scrollToTop();
        }
    });
    
    document.getElementById('nextPage').addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderCurrentPage();
            scrollToTop();
        }
    });
});

// Fetch all anime from multiple pages
async function fetchAllAnime() {
    const maxPages = 20; // Fetch first 20 pages (about 500 anime)
    const promises = [];
    
    for (let page = 1; page <= maxPages; page++) {
        promises.push(
            api.fetchData(`/anime?limit=25&page=${page}`)
                .then(response => response.data)
                .catch(error => {
                    console.error(`Error fetching page ${page}:`, error);
                    return [];
                })
        );
    }
    
    const results = await Promise.all(promises);
    allAnimeData = results.flat().filter(anime => anime && anime.mal_id);
    
    // Remove duplicates based on mal_id
    const uniqueAnime = new Map();
    allAnimeData.forEach(anime => {
        if (!uniqueAnime.has(anime.mal_id)) {
            uniqueAnime.set(anime.mal_id, anime);
        }
    });
    allAnimeData = Array.from(uniqueAnime.values());
}

// Apply filters and sorting
function applyFiltersAndSort() {
    filteredAnimeData = [...allAnimeData];
    
    // Apply search filter
    if (currentFilters.search) {
        filteredAnimeData = filteredAnimeData.filter(anime => 
            anime.title.toLowerCase().includes(currentFilters.search) ||
            (anime.title_english && anime.title_english.toLowerCase().includes(currentFilters.search))
        );
    }
    
    // Apply type filter
    if (currentFilters.type) {
        filteredAnimeData = filteredAnimeData.filter(anime => 
            anime.type && anime.type.toLowerCase() === currentFilters.type.toLowerCase()
        );
    }
    
    // Apply status filter
    if (currentFilters.status) {
        filteredAnimeData = filteredAnimeData.filter(anime => 
            anime.status && anime.status.toLowerCase().includes(currentFilters.status.toLowerCase())
        );
    }
    
    // Apply sorting
    switch(currentFilters.sort) {
        case 'title-asc':
            filteredAnimeData.sort((a, b) => a.title.localeCompare(b.title));
            break;
        case 'title-desc':
            filteredAnimeData.sort((a, b) => b.title.localeCompare(a.title));
            break;
        case 'score-desc':
            filteredAnimeData.sort((a, b) => (b.score || 0) - (a.score || 0));
            break;
        case 'score-asc':
            filteredAnimeData.sort((a, b) => (a.score || 0) - (b.score || 0));
            break;
        case 'popularity':
            filteredAnimeData.sort((a, b) => (a.popularity || 999999) - (b.popularity || 999999));
            break;
    }
    
    // Recalculate total pages
    totalPages = Math.ceil(filteredAnimeData.length / itemsPerPage);
    
    // Reset to page 1 if current page exceeds total
    if (currentPage > totalPages) {
        currentPage = 1;
    }
}

// Render current page
function renderCurrentPage() {
    const animeGrid = document.getElementById('animeGrid');
    const paginationControls = document.getElementById('paginationControls');
    
    // Calculate pagination
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const pageAnime = filteredAnimeData.slice(start, end);
    
    // Clear grid
    animeGrid.innerHTML = '';
    
    // Check if empty
    if (pageAnime.length === 0) {
        animeGrid.innerHTML = `
            <div class="col-span-full empty-state">
                <div class="empty-state-icon">😔</div>
                <h3 class="text-2xl font-bold mb-2">No anime found</h3>
                <p class="text-gray-400 mb-6">Try adjusting your filters or search terms</p>
                <button onclick="resetFilters()" class="pagination-btn">
                    Reset Filters
                </button>
            </div>
        `;
        paginationControls.classList.add('hidden');
        return;
    }
    
    // Render anime cards
    pageAnime.forEach((anime, index) => {
        const card = createAnimeCard(anime, index);
        animeGrid.appendChild(card);
    });
    
    // Show and update pagination
    paginationControls.classList.remove('hidden');
    updatePaginationControls();
}

// Create anime card
function createAnimeCard(anime, index) {
    const card = document.createElement('div');
    card.className = 'anime-card stagger-item cursor-pointer';
    card.style.animationDelay = `${index * 0.03}s`;
    card.style.transform = 'translateY(20px)';
    
    const imageUrl = anime.images?.jpg?.image_url || 'assets/placeholder.jpg';
    const score = anime.score ? anime.score.toFixed(1) : 'N/A';
    const episodes = anime.episodes || '?';
    const year = anime.year || '?';
    const status = anime.status || 'Unknown';
    const type = anime.type || 'Unknown';
    
    card.innerHTML = `
        <div class="relative">
            <div class="h-72 overflow-hidden">
                <img src="${imageUrl}" 
                     alt="${anime.title}" 
                     class="w-full h-full object-cover"
                     onerror="this.src='assets/placeholder.jpg'"
                     loading="lazy">
            </div>
            <div class="absolute top-3 right-3">
                <span class="score-badge">
                    ⭐ ${score}
                </span>
            </div>
            ${type !== 'Unknown' ? `
                <div class="absolute top-3 left-3">
                    <span class="px-3 py-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs font-bold rounded-full">
                        ${type}
                    </span>
                </div>
            ` : ''}
            ${anime.airing ? `
                <div class="absolute bottom-3 left-3">
                    <span class="px-3 py-1 bg-gradient-to-r from-red-500 to-red-600 text-white text-xs font-bold rounded-full animate-pulse">
                        AIRING
                    </span>
                </div>
            ` : ''}
        </div>
        
        <div class="p-5">
            <h3 class="text-lg font-bold text-white mb-3 line-clamp-2 min-h-[3.5rem]">${anime.title}</h3>
            
            <div class="space-y-2 mb-4">
                <div class="flex justify-between text-sm">
                    <span class="text-gray-400">Episodes:</span>
                    <span class="font-medium text-lime-400">${episodes}</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-400">Year:</span>
                    <span class="font-medium text-lime-400">${year}</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-400">Status:</span>
                    <span class="font-medium text-lime-400 text-xs">${status}</span>
                </div>
            </div>
            
            <button class="w-full py-2.5 bg-gradient-to-r from-lime-500 to-green-600 hover:from-lime-600 hover:to-green-700 text-white font-bold rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg">
                Watch Now
            </button>
        </div>
    `;
    
    // Click handlers
    card.addEventListener('click', (e) => {
        if (!e.target.closest('button')) {
            window.location.href = `detail.html?id=${anime.mal_id}`;
        }
    });
    
    const watchButton = card.querySelector('button');
    watchButton.addEventListener('click', (e) => {
        e.stopPropagation();
        window.location.href = `detail.html?id=${anime.mal_id}`;
    });
    
    return card;
}

// Update pagination controls
function updatePaginationControls() {
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');
    const pageNumbersContainer = document.getElementById('pageNumbers');
    const currentPageDisplay = document.getElementById('currentPageDisplay');
    const totalPagesDisplay = document.getElementById('totalPagesDisplay');
    
    // Update buttons
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
    
    // Update page display
    currentPageDisplay.textContent = currentPage;
    totalPagesDisplay.textContent = totalPages;
    
    // Clear page numbers
    pageNumbersContainer.innerHTML = '';
    
    // Calculate page range to show
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, currentPage + 2);
    
    // Adjust for edges
    if (endPage - startPage < 4) {
        if (startPage === 1) {
            endPage = Math.min(totalPages, startPage + 4);
        } else if (endPage === totalPages) {
            startPage = Math.max(1, endPage - 4);
        }
    }
    
    // Add first page if not in range
    if (startPage > 1) {
        addPageNumber(1, pageNumbersContainer);
        if (startPage > 2) {
            const ellipsis = document.createElement('span');
            ellipsis.className = 'text-gray-400 px-2';
            ellipsis.textContent = '...';
            pageNumbersContainer.appendChild(ellipsis);
        }
    }
    
    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
        addPageNumber(i, pageNumbersContainer);
    }
    
    // Add last page if not in range
    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            const ellipsis = document.createElement('span');
            ellipsis.className = 'text-gray-400 px-2';
            ellipsis.textContent = '...';
            pageNumbersContainer.appendChild(ellipsis);
        }
        addPageNumber(totalPages, pageNumbersContainer);
    }
}

// Add page number button
function addPageNumber(pageNum, container) {
    const pageNumber = document.createElement('div');
    pageNumber.className = `page-number ${pageNum === currentPage ? 'active' : ''}`;
    pageNumber.textContent = pageNum;
    pageNumber.addEventListener('click', () => {
        currentPage = pageNum;
        renderCurrentPage();
        scrollToTop();
    });
    container.appendChild(pageNumber);
}

// Reset all filters
function resetFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('sortSelect').value = 'title-asc';
    document.getElementById('typeFilter').value = '';
    document.getElementById('statusFilter').value = '';
    
    currentFilters = {
        search: '',
        type: '',
        status: '',
        sort: 'title-asc'
    };
    
    currentPage = 1;
    applyFiltersAndSort();
    renderCurrentPage();
}

// Scroll to top smoothly
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// Export for use in HTML onclick
window.resetFilters = resetFilters;