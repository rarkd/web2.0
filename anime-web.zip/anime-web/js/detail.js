// Get anime ID from URL
const urlParams = new URLSearchParams(window.location.search);
const animeId = urlParams.get('id');

document.addEventListener('DOMContentLoaded', async () => {
    const loading = document.getElementById('loading');
    const animeDetail = document.getElementById('animeDetail');
    
    if (!animeId) {
        loading.innerHTML = `
            <div class="text-center">
                <div class="text-red-400 text-xl font-bold mb-4">Invalid Anime ID</div>
                <button onclick="window.location.href='index.html'" class="watch-btn">
                    <span class="relative z-10">Go to Home</span>
                </button>
            </div>
        `;
        return;
    }
    
    try {
        // Fetch anime details
        const data = await api.fetchData(`/anime/${animeId}/full`);
        const anime = data.data;
        
        // Hide loading and show content
        loading.classList.add('hidden');
        animeDetail.classList.remove('hidden');
        
        // Populate all anime details
        populateAnimeDetails(anime);
        
        // Set up interactions
        setupInteractions(anime);
        
    } catch (error) {
        console.error('Error fetching anime details:', error);
        loading.innerHTML = `
            <div class="text-center">
                <div class="text-red-400 text-xl font-bold mb-4">Failed to load anime details</div>
                <p class="text-gray-400 mb-6">Please try again later</p>
                <button onclick="window.location.href='index.html'" class="watch-btn">
                    <span class="relative z-10">Go to Home</span>
                </button>
            </div>
        `;
    }
});

function populateAnimeDetails(anime) {
    // Images
    const posterUrl = anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url || 'assets/placeholder.jpg';
    document.getElementById('animePoster').src = posterUrl;
    document.getElementById('backdropImage').src = posterUrl;
    
    // Basic info
    document.getElementById('animeTitle').textContent = anime.title || 'Unknown Title';
    document.getElementById('animeScore').textContent = anime.score ? anime.score.toFixed(1) : 'N/A';
    document.getElementById('animeEpisodes').textContent = anime.episodes || '?';
    document.getElementById('animeType').textContent = anime.type || '?';
    document.getElementById('animeYear').textContent = anime.year || '?';
    
    // Duration
    const duration = anime.duration || 'Unknown';
    document.getElementById('animeDuration').textContent = duration;
    
    // Status badge
    setStatusBadge(anime.status);
    
    // Rank badge
    if (anime.rank) {
        const rankBadge = document.getElementById('animeRank');
        rankBadge.textContent = `#${anime.rank} Ranked`;
        rankBadge.classList.remove('hidden');
    }
    
    // Genres
    const genresContainer = document.getElementById('animeGenres');
    genresContainer.innerHTML = '';
    if (anime.genres && anime.genres.length > 0) {
        anime.genres.forEach(genre => {
            const tag = document.createElement('span');
            tag.className = 'genre-tag';
            tag.textContent = genre.name;
            tag.addEventListener('click', () => {
                window.location.href = `genres.html?genre=${genre.mal_id}`;
            });
            genresContainer.appendChild(tag);
        });
    } else {
        genresContainer.innerHTML = '<span class="text-gray-400">No genres available</span>';
    }
    
    // Synopsis
    const synopsis = anime.synopsis || 'No synopsis available.';
    document.getElementById('animeSynopsis').textContent = synopsis;
    
    // Additional Information
    document.getElementById('animeTitleJapanese').textContent = anime.title_japanese || 'N/A';
    document.getElementById('animeSource').textContent = anime.source || 'Unknown';
    
    const season = anime.season && anime.year 
        ? `${anime.season.charAt(0).toUpperCase() + anime.season.slice(1)} ${anime.year}`
        : anime.season || anime.year || 'Unknown';
    document.getElementById('animeSeason').textContent = season;
    
    // Studios
    const studios = anime.studios && anime.studios.length > 0
        ? anime.studios.map(s => s.name).join(', ')
        : 'Unknown';
    document.getElementById('animeStudio').textContent = studios;
    
    document.getElementById('animeRating').textContent = anime.rating || 'Not rated';
    document.getElementById('animePopularity').textContent = anime.popularity ? `#${anime.popularity}` : 'N/A';
    
    // Statistics
    document.getElementById('animeRanking').textContent = anime.rank ? `#${anime.rank}` : 'N/A';
    document.getElementById('animeMembers').textContent = anime.members ? anime.members.toLocaleString() : 'N/A';
    document.getElementById('animeFavorites').textContent = anime.favorites ? anime.favorites.toLocaleString() : 'N/A';
    document.getElementById('animeScoredBy').textContent = anime.scored_by ? anime.scored_by.toLocaleString() : 'N/A';
}

function setStatusBadge(status) {
    const statusElement = document.getElementById('animeStatus');
    statusElement.className = 'status-badge';
    
    // Add pulse animation icon
    const pulseIcon = '<span class="w-2 h-2 bg-current rounded-full inline-block mr-2 animate-pulse"></span>';
    
    if (!status) {
        statusElement.className += ' status-upcoming';
        statusElement.innerHTML = pulseIcon + 'Unknown';
        return;
    }
    
    const statusLower = status.toLowerCase();
    
    if (statusLower.includes('airing') || statusLower.includes('currently')) {
        statusElement.className += ' status-airing';
        statusElement.innerHTML = pulseIcon + 'Airing';
    } else if (statusLower.includes('finished')) {
        statusElement.className += ' status-finished';
        statusElement.innerHTML = '<span class="w-2 h-2 bg-current rounded-full inline-block mr-2"></span>Finished';
    } else if (statusLower.includes('upcoming') || statusLower.includes('not yet')) {
        statusElement.className += ' status-upcoming';
        statusElement.innerHTML = pulseIcon + 'Upcoming';
    } else {
        statusElement.className += ' status-upcoming';
        statusElement.innerHTML = '<span class="w-2 h-2 bg-current rounded-full inline-block mr-2"></span>' + status;
    }
}

function setupInteractions(anime) {
    // Watch button
    const watchBtn = document.getElementById('watchBtn');
    watchBtn.addEventListener('click', () => {
        // In a real app, this would navigate to a video player
        alert(`Watch functionality for "${anime.title}" would be implemented here.\n\nThis would typically:\n• Open a video player\n• Stream the anime\n• Track watch progress`);
    });
    
    // Add to List button
    const addToListBtn = document.getElementById('addToListBtn');
    addToListBtn.addEventListener('click', () => {
        // Show success feedback
        const originalText = addToListBtn.innerHTML;
        addToListBtn.innerHTML = `
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
            </svg>
            Added!
        `;
        addToListBtn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
        
        setTimeout(() => {
            addToListBtn.innerHTML = originalText;
            addToListBtn.style.background = '';
        }, 2000);
    });
    
    // Share button
    const shareBtn = document.getElementById('shareBtn');
    shareBtn.addEventListener('click', async () => {
        const shareData = {
            title: anime.title,
            text: `Check out ${anime.title} on ANIVIA!`,
            url: window.location.href
        };
        
        // Try native share API first
        if (navigator.share) {
            try {
                await navigator.share(shareData);
            } catch (err) {
                if (err.name !== 'AbortError') {
                    fallbackShare(shareData);
                }
            }
        } else {
            fallbackShare(shareData);
        }
    });
}

function fallbackShare(shareData) {
    // Fallback: Copy to clipboard
    const url = shareData.url;
    
    if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(() => {
            showShareNotification('Link copied to clipboard!');
        }).catch(() => {
            showShareNotification('Could not copy link');
        });
    } else {
        // Old school clipboard method
        const textArea = document.createElement('textarea');
        textArea.value = url;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.select();
        
        try {
            document.execCommand('copy');
            showShareNotification('Link copied to clipboard!');
        } catch (err) {
            showShareNotification('Could not copy link');
        }
        
        document.body.removeChild(textArea);
    }
}

function showShareNotification(message) {
    // Create notification
    const notification = document.createElement('div');
    notification.className = 'fixed bottom-8 right-8 bg-gradient-to-r from-lime-500 to-green-600 text-black px-6 py-4 rounded-lg shadow-lg z-50 font-bold flex items-center gap-3';
    notification.innerHTML = `
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
        </svg>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    notification.style.animation = 'slideInUp 0.3s ease';
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutDown 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add animation keyframes
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInUp {
        from {
            transform: translateY(100px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutDown {
        from {
            transform: translateY(0);
            opacity: 1;
        }
        to {
            transform: translateY(100px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);